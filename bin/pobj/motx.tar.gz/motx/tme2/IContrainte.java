package pobj.motx.tme2;

public interface IContrainte {

	int reduce(GrillePotentiel grille);
	
}
