package pobj.pinboard.document;

import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Separator;
import javafx.scene.control.ToolBar;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class EditorWindow {
	
	private MenuBar barreMenu;
	private ToolBar barreBouttons = new ToolBar();
	private Canvas zoneDessin;
	private Label statut = new Label();
	private Separator separateur = new Separator();
	private VBox layout;
	private Board planche = new Board();
	
	public EditorWindow(Stage stage) {
		stage.setTitle("PinBoard");
		this.layout = new VBox();
		this.newCanvas( 400 , 600 );
		this.newBarreMenu();
		this.newToolBar();
		this.statut.textProperty().set("Zone de dessin");
		this.layout.getChildren().addAll(this.barreMenu , new Separator() ,this.barreBouttons,new Separator(),this.zoneDessin,new Separator(),this.statut);
		Scene scene = new Scene(this.layout);
		stage.setScene(scene);
		stage.show();
	}

	private void newToolBar() {
		
	}

	private void newBarreMenu() {
		Menu menu1 = new Menu( "Menu 1") ;
		menu1.getItems().addAll( new MenuItem("Option 1"));
		this.barreMenu  = new MenuBar(menu1);
	}

	private void newCanvas(int hauteur, int longueur) {

		this.zoneDessin = new Canvas( longueur , hauteur );
		
	}

}
